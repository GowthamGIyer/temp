# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


import pandas as pd
import numpy as np
# from DIHC_FeatureManager import DIHC_FeatureManager
# from DIHC_FeatureManager import *
# import DIHC_FeatureManager
#from DIHC_Package.DIHC_FeatureManager.DIHC_FeatureManager import *
from front_DIHC_ML_lib.DIHC_FeatureManager import *

# Gowtham_edit
import os
import xlsxwriter
#from EMBC_stress_analysis_V11_DIHC_3 import sample_epochs
##if __name__ == "__main__":
##    import EMBC_stress_analysis_V11_DIHC_3
##import EMBC_stress_analysis_V11_DIHC_3.sample_epochs

if __name__ == '__main__':

    #!!!!!!!!!!!!!!print(f'Data reading started...')
    
    # Gowtham_edit
    #samp_df = pd.read_csv('./DIHC_Package/signal_data.csv')
    #samp_df = pd.read_csv('./DIHC_Package/signal_data.csv', nrows = 300)
    
    #!!!!!!!!!!!!!!print(f'Data reading completed...')
    ##print(samp_df)
    #print(samp_df.shape, samp_df.columns)

    #!!!!!!!!!!!!!!print(f'Data minimization started...')
    # sig_freq = 1 #256
    # samp_data = np.array([52, 54, 6, 45, 14, 40, 42, 48, 52, 20, 28, 8, 63, 47, 23])

    # Gowtham_edit
    sig_freq = 1
    #sig_freq = 256
        
    # samp_data = samp_df['signal'].values.tolist()
    
    # Gowtham_edit
    #samp_data = samp_df.loc[:20*sig_freq-1, 'signal'].values#.tolist()
    ##samp_data = samp_df.loc[:,'signal'].values#.tolist();
    ##samp_data = EMBC_stress_analysis_V11_DIHC_3.sample_epochs;    
    samp_data_list = sample_epochs;
    samp_data = np.array(samp_data_list);
    
    # samp_data = samp_df.loc[:5100, 'signal'].values#.tolist()
    # samp_data = samp_df.iloc[:20*256-1, 0:1].values#.tolist()
    # print(len(samp_data))
    
    # Gowtham_edit
    #samp_data = samp_df;
    #samp_data_1 = [1 for i in range(300)];
    #samp_data = pd.DataFrame(samp_data_1);
    
    #!!!!!!!!!!!!!!print(samp_data.shape, samp_data)
    #!!!!!!!!!!!!!!print(type(samp_data));
    #!!!!!!!!!!!!!!print(f'Data minimization completed...')


    #!!!!!!!!!!!!!!print(f'Data segmentation started...')
    feat_manager = DIHC_FeatureManager()
    # Gowtham_edit
    #seg_df = feat_manager.get_segments_for_data(samp_data, segment_length=5, signal_frequency=sig_freq)
    print("samp_data len: ", len(samp_data));
    #!!!Req_print!!!print("samp_data epochs: ", samp_data);
    seg_df = feat_manager.get_segments_for_data(samp_data, segment_length = 1, signal_frequency=sig_freq)
    #!!!!!!!!!!!!!!print(f'Data segmentation completed...')

    #!!!!!!!!!!!!!!print(f'Showing segments...')
    #!!!!!!!!!!!!!!print(seg_df.shape)
    #!!!!!!!!!!!!!!print(seg_df)


    #!!!!!!!!!!!!!!print(f'Feature extraction started...')
    feat_manager = DIHC_FeatureManager()
    # feat_df = feat_manager.extract_features_from_data(samp_data, segment_length=5, signal_frequency=sig_freq)
    
    # Gowtham_edit
    feat_df = feat_manager.extract_features_from_data(samp_data, segment_length=None, signal_frequency=sig_freq, has_matlab_engine=False)
    #feat_df = feat_manager.extract_features_from_data(samp_data, segment_length=5, signal_frequency=sig_freq, has_matlab_engine=False)
    
    
    # feat_df = feat_manager.extract_features_from_data(samp_data, feature_names=[DIHC_FeatureGroup.fdNlPw, DIHC_FeatureGroup.fdNlPwBnd], segment_length=5, signal_frequency=sig_freq, has_matlab_engine=False)
    # feat_df = feat_manager.extract_features_from_data(samp_data, feature_names=[DIHC_FeatureGroup.tdNlEn, DIHC_FeatureGroup.td], segment_length=5, signal_frequency=sig_freq, has_matlab_engine=True)
    # feat_df = feat_manager.extract_features_from_data(samp_data, feature_names=[DIHC_FeatureGroup.tdNlEn, DIHC_FeatureGroup.tdNl], segment_length=5, signal_frequency=sig_freq, has_matlab_engine=True)
    #!!!!!!!!!!!!!!print(f'Feature extraction completed...')

    #!!!!!!!!!!!!!!print(f'Showing features...')
    # print(len(feat_df.columns.values.tolist()), feat_df.columns.values.tolist())
    #!!!!!!!!!!!!!!print(feat_df.shape)
    #!!!!!!!!!!!!!!print(feat_df)

    # Gowtham_edit
    file_path_xl = os.getcwd();
    #!!!!!!!!!!!!!!print(file_path_xl);
    #fn_excel_writer(file_path_xl, selected_stress_stages, num_subjects_select, start_index_subjects, window_size);
    #workbook = xlsxwriter.Workbook(file_path_xl + "\\" + "DIHC_Features" + ".xlsx");
    #worksheet = workbook.add_worksheet("Extracted Features");
    #df = pd.DataFrame(feat_df); 
    #worksheet.write(df);
    filename_path = file_path_xl + "\\" + "DIHC_Features_2" + ".xlsx";
    feat_df.to_excel(excel_writer = filename_path)
    df_non_nan_inf = feat_df.replace([np.nan, -np.inf], 0)
    
    for feature_index in range(len(features_list)):
        #print(feature_index);
        #print(features_list[feature_index]);
        feature_buffer_list[feature_index].append(df_non_nan_inf._get_value(0,features_list[feature_index]));
    
        
    #worksheet = workbook.add_worksheet("Extracted Features");
    #workbook.close();
    # # matlab test
    # import matlab.engine
    # eng = matlab.engine.start_matlab()
    # # tf = eng.sumanddiff(4,2,nargout=2)
    # tf = eng.fuzzyEn2(samp_data.tolist(),2,1,0.2,nargout=1)
    # print(tf)
    # eng.quit()

