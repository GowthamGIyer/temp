function [s,d] = sumanddiff(a,b)
s = a+b;
d = a-b;