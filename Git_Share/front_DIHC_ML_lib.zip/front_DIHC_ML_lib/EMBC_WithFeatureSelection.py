#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  5 14:48:05 2024

@author: shivangayathri
"""


import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_predict

from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, accuracy_score, precision_recall_fscore_support

from sklearn.decomposition import PCA

import matplotlib.pyplot as plt
import seaborn as sns

# Suppress all warnings
import warnings
warnings.simplefilter('ignore')

# import glob, os
from pathlib import Path

from sklearn.feature_selection import RFECV


def getClassificationResults(model, X, y):
    
    # Stratified 5-fold crossvalidation
    predictions = cross_val_predict(model, X, y, cv = 5)
                                            
    p,r,f1,s = precision_recall_fscore_support(y, predictions, average='macro')
    
    # Print performance of the model
    p   = np.round(p, 3)
    r   = np.round(r, 3)
    acc = np.round(accuracy_score(y, predictions), 3)
    f1  = np.round(f1, 3)
    
    model_data = {
               'Metrics': ["Precision", "Recall", "Accuracy", "F1"],
               'Values': [p, r, acc, f1]
               }
    
    model_perf_df = pd.DataFrame(model_data)
    return model_perf_df
    

######### Main Program ##########################################

#f = "Data/data_5mins.xlsx"
#f = 'D:/Gowtham/research/Amrita/Technical Papers/EMBC/EMBC_stress_analysis/ShivaSir/nonEEG_Physionet_Features_300.xlsx'
#f = 'D:/Gowtham/research/Amrita/Technical Papers/EMBC/EMBC_stress_analysis/ShivaSir/nonEEG_Physionet_Features_240.xlsx'
#f = 'D:/Gowtham/research/Amrita/Technical Papers/EMBC/EMBC_stress_analysis/ShivaSir/nonEEG_Physionet_Features_180.xlsx'
#f = 'D:/Gowtham/research/Amrita/Technical Papers/EMBC/EMBC_stress_analysis/ShivaSir/nonEEG_Physionet_Features_120.xlsx'
#f = 'D:/Gowtham/research/Amrita/Technical Papers/EMBC/01_EMBC_stress_analysis/ShivaSir/Inputs_1236/nonEEG_Physionet_Features1_60.xlsx'
f = 'D:/Gowtham/research/Amrita/Technical Papers/EMBC/01_EMBC_stress_analysis/ShivaSir/Inputs_1246/nonEEG_Physionet_Features5_300.xlsx'

features = pd.read_excel(f, usecols='C:UW');
target_vec   = pd.read_excel(f, usecols='B');
target   = np.array(target_vec).ravel()

scaler = StandardScaler();
features_scaled = scaler.fit_transform(features);

print("Total number of features in original data: ", len(features.columns))


######### Step 1: Feature Selection ##########################################

estimator = SVC(kernel='linear')
selector = RFECV(estimator, step=1, cv=5, 
                 scoring='accuracy')

selector.fit(features_scaled, target)
print("No of selected features:", selector.n_features_)

selected_feature_inds = selector.get_support(indices=True)
print("The selected features are: ", features.columns[selected_feature_inds])

# Reduced feature set based on selected features
features_reduced = selector.transform(features_scaled)

######### Step 2: Visualisation reduced features #######################

pca = PCA(n_components=2)
pca_features = pca.fit_transform(features_reduced)
#pca_features = pca.fit_transform(features_scaled)

PC1 = pca_features[:,0]
PC2 = pca_features[:,1]

pca_df = pd.DataFrame({'PC1': PC1, 'PC2': PC2, 'target': target }) 


sns.scatterplot(data=pca_df, 
                x="PC1", 
                y="PC2", 
                hue="target", style="target", palette="deep")
 
plt.title("Figure 1: Scatter Plot",
          fontsize=16)
plt.xlabel('First Principal Component',
           fontsize=16)
plt.ylabel('Second Principal Component',
           fontsize=16)


######### Step 3: Model Fitting using reduced features #######################


lrmodel = LogisticRegression(multi_class='ovr')
rfmodel = RandomForestClassifier(random_state=42)

lr_perf_df = getClassificationResults(lrmodel, features_reduced, target)
rf_perf_df = getClassificationResults(rfmodel, features_reduced, target)

print("Log Reg:")
print(lr_perf_df)

print("Random Forest")
print(rf_perf_df)

# Adding code to write results in excel
lr_perf_df['Signal Length'] = np.repeat([Path(f).stem], 4)
rf_perf_df['Signal Length'] = np.repeat([Path(f).stem], 4)

final_lr_df = pd.DataFrame()
final_rf_df = pd.DataFrame()
    
final_lr_df = final_lr_df._append(lr_perf_df, ignore_index=True)
final_rf_df = final_rf_df._append(rf_perf_df, ignore_index=True)

final_lr_df.to_csv("final_lr_results.csv")
final_rf_df.to_csv("final_rf_results.csv")




