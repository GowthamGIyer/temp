#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb  1 16:46:53 2024
"""

# Library Imports
import pandas as pd
import numpy as np
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import classification_report
from sklearn.preprocessing import StandardScaler

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, accuracy_score, precision_recall_fscore_support
import glob, os
from pathlib import Path


#file_path = '/Users/shivangayathri/Library/CloudStorage/OneDrive-Amritauniversity/MyStudents/Gowtham/Working/Stress Paper/Data/'
file_path = 'D:/Gowtham/research/Amrita/Technical Papers/EMBC/01_EMBC_stress_analysis/ShivaSir/Inputs_246'

def getClassificationResults(model, X, y):
    
    # Stratified 5-fold crossvalidation
    predictions = cross_val_predict(model, X, y, cv = 5)
                                            
    p,r,f1,s = precision_recall_fscore_support(target, predictions, average='macro')
    
    # Print performance of the model
    p   = np.round(p, 3)
    r   = np.round(r, 3)
    acc = np.round(accuracy_score(target, predictions), 3)
    f1  = np.round(f1, 3)
    
    model_data = {
               'Metrics': ["Precision", "Recall", "Accuracy", "F1"],
               'Values': [p, r, acc, f1]
               }
    
    model_perf_df = pd.DataFrame(model_data)
    return model_perf_df
    
    

os.chdir(file_path)

final_lr_df = pd.DataFrame()
final_rf_df = pd.DataFrame()

for f in glob.glob("*.xlsx"):
    
    print(Path(f).stem)
    features = pd.read_excel(f, usecols='C:UW');
    target   = pd.read_excel(f, usecols='B');
    target   = np.array(target).ravel()
    
    scaler = StandardScaler();
    scaled_features = scaler.fit_transform(features);

    lrmodel = LogisticRegression(multi_class='ovr')
    rfmodel = RandomForestClassifier(random_state=42)
    
    lr_perf_df = getClassificationResults(lrmodel, scaled_features, target)
    rf_perf_df = getClassificationResults(rfmodel, scaled_features, target)
    
    lr_perf_df['Signal Length'] = np.repeat([Path(f).stem], 4)
    rf_perf_df['Signal Length'] = np.repeat([Path(f).stem], 4)
    
    final_lr_df = final_lr_df._append(lr_perf_df, ignore_index=True)
    final_rf_df = final_rf_df._append(rf_perf_df, ignore_index=True)
    

final_lr_df.to_csv("final_lr_results.csv")
final_rf_df.to_csv("final_rf_results.csv")
    
    
    
    
    
    


