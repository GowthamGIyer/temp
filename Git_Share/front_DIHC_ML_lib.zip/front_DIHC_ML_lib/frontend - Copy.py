import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import turtle as trt
# File browse  ******
import tkinter
from tkinter import filedialog
import os
# File browse  ******
from datetime import datetime
# Frequency domain transform  ******
from scipy import pi
from scipy.fftpack import fft

# Libs for unser input menu
from tkinter import *
from PIL import ImageTk, Image
from tkinter import ttk

# Libs for user entry form
import cgi, cgitb

import enum

# Libs for writing into/reading from Excel file    
#import xlwt
#from xlwt import Workbook
import xlsxwriter

import openpyxl

import shutil

def page_01():
    #global num_records;
    #image_path = dir_os.getcwd() + "\\" + "front_DIHC_ML_lib" + "\\" + "Capture.PNG");
    image_path_1 = dir_os.path.join(dir_os.getcwd(), "front_DIHC_ML_lib");
    image_path = dir_os.path.join(image_path_1, "Capture.PNG");
    #img_raw = Image.open(dir_os.path.join(dir_os.getcwd(), "front_DIHC_ML_lib" , "Capture.PNG"))
    
    
    img_raw = Image.open(image_path);
    img_resize = img_raw.resize((400, 200), Image.ANTIALIAS)
    main_title = "Engineering for Health: Human Stress Analysis"
    num_subjects_max = 20;
    window_size_max = 300;
    #mod1_file_path_name = "";
        
    root_01 = Tk();
    root_01.title(main_title);
    mainframe = Frame(root_01, background = "black");
        
    mainframe.grid(column = 0,row = 0, sticky = (W,E));
    mainframe.columnconfigure(0, weight = 1);
    mainframe.rowconfigure(0, weight = 1);
    mainframe.pack();
    
    img = ImageTk.PhotoImage(img_resize);

    Label(mainframe, image = img).grid(row = 1, column = 1);
    for space_count in range(2,3):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
    
    Label(mainframe, text = main_title, fg = "white", bg = "black").grid(row = 4, column = 1);
    #Label(mainframe, text = "(Please select relevant options)").grid(row = 4, column = 1);
    for space_count in range(6,7):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
        
    page_heading = "Non-EEG Dataset: Analysis-Configurations";
    Label(mainframe, text = page_heading, fg = "white", bg = "black").grid(row = 8, column = 1);
    for space_count in range(9,10):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
        
    Label(mainframe, text = "Should 2nd, 3rd and 4th relaxation states be removed?", fg = "white", bg = "black").grid(row = 11, column = 1);
    menu_query1_01 = StringVar(root_01);
    #if(back_button_active == 0):
    menu_query1_01.set('Click to choose option'); # set the default option
    #else:
        #menu_query1_01.set(contractor_record[5]);
    query1_options = ['YES', 'NO'];
    popupMenu = OptionMenu(mainframe, menu_query1_01, *query1_options);
    popupMenu.grid(row = 12, column = 1);
    for space_count in range(13, 14):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
        
    Label(mainframe, text = "Choose number of subjects to be analyzed", fg = "white", bg = "black").grid(row = 15, column = 1);
    menu_query2_01 = StringVar(root_01);
    #if(back_button_active == 0):
    menu_query2_01.set('Click to choose option'); # set the default option
    #else:
        #menu_query1_01.set(contractor_record[5])
    query2_options = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20'];
    popupMenu = OptionMenu(mainframe, menu_query2_01, *query2_options);
    popupMenu.grid(row = 16, column = 1);
    for space_count in range(17, 18):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
        
    # Button to refactor subjects starting index
    def subject_index_factor():
        global menu_query3_01_sub;
        menu_entry_sub = menu_query2_01.get()
        if(menu_entry_sub != "Click to choose option"):
            print("query3_options_temp getting set");
            print("menu_entry_sub", menu_entry_sub);
            query3_options_temp = list(range(1, (num_subjects_max - int(menu_entry_sub) + 2)));
            print("query3_options_temp", query3_options_temp);
            #f = open("subject_factor.txt", "w");
            #f.writelines(str(query3_options_temp));
            #f.close();
            menu_query3_01_sub = StringVar(root_01);
            menu_query3_01_sub.set('Click to choose option'); # set the default option
            popupMenu = OptionMenu(mainframe, menu_query3_01_sub, *query3_options_temp);
            popupMenu.config(width = 22);
            popupMenu.grid(row = 20, column = 1);
        else:
            Label(mainframe, text = "Please choose number of subject and confirm !", fg = "red", bg = "black").grid(row = 18, column = 1);
            print("query3_options not getting set");
            
    sub_confirm = Button(mainframe, text = "Confirm", font = ("Arial", 10), width = 10, command = subject_index_factor);
    sub_confirm.grid(row = 17, column = 1);
    
    Label(mainframe, text = "Choose starting index of subjects", fg = "white", bg = "black").grid(row = 19, column = 1);
    menu_query3_01 = StringVar(root_01);
    #if(back_button_active == 0):
    menu_query3_01.set('Click to choose option'); # set the default option
    #else:
        #menu_query1_01.set(contractor_record[5])
    query3_options = [0];
    menu_entry_sub = menu_query2_01.get();
    print("menu_entry_sub: ",menu_entry_sub);
       
    #if(menu_entry_sub != "Click to choose option"):
    #    sub_file = open("subject_factor.txt", "r");
    #    query3_options = sub_file.read();
    #    print("query3_options: ", query3_options);
    #    #query3_options = list(range(num_subjects_max - int(menu_entry_sub)));
    
    popupMenu = OptionMenu(mainframe, menu_query3_01, *query3_options);
    popupMenu.config(width = 22);
    popupMenu.grid(row = 20, column = 1);
    for space_count in range(21, 22):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
        
    Label(mainframe, text = "Choose sample window size", fg = "white", bg = "black").grid(row = 23, column = 1);
    menu_query4_01 = StringVar(root_01);
    #if(back_button_active == 0):
    menu_query4_01.set('Click to choose option'); # set the default option
    #else:
        #menu_query1_01.set(contractor_record[5])
    #query4_options = ['50', '100', '150', '200', '250', '300'];
    query4_options = ['30', '60', '90', '120', '150', '180', '210', '240', '270', '300'];
    popupMenu = OptionMenu(mainframe, menu_query4_01, *query4_options);
    popupMenu.grid(row = 24, column = 1);
    for space_count in range(25, 26):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
    
    
    # Button to refactor subjects starting index
    def window_index_factor():
        global menu_query5_01_win;
        menu_entry_win = menu_query4_01.get()
        if(menu_entry_win != "Click to choose option"):
            print("query5_options_temp getting set");
            print("menu_entry_win", menu_entry_win);
            query5_options_temp = list(range(1, (window_size_max - int(menu_entry_win) + 2)));
            print("query5_options_temp", query5_options_temp);
            #f = open("window_factor.txt", "w");
            #f.writelines(str(query5_options_temp));
            #f.close();
            menu_query5_01_win = StringVar(root_01);
            menu_query5_01_win.set('Click to choose option'); # set the default option
            popupMenu = OptionMenu(mainframe, menu_query5_01_win, *query5_options_temp);
            popupMenu.config(width = 22);
            popupMenu.grid(row = 28, column = 1);
        else:
            Label(mainframe, text = "Please choose window size and confirm !", fg = "red", bg = "black").grid(row = 26, column = 1);
            print("query3_options not getting set");
            
    sub_confirm = Button(mainframe, text = "Confirm", font = ("Arial", 10), width = 10, command = window_index_factor);
    sub_confirm.grid(row = 25, column = 1);
    
    Label(mainframe, text = "Choose starting index of window", fg = "white", bg = "black").grid(row = 27, column = 1);
    menu_query5_01 = StringVar(root_01);
    #if(back_button_active == 0):
    menu_query5_01.set('Click to choose option'); # set the default option
    #else:
        #menu_query1_01.set(contractor_record[5])
    query5_options = [0];
    menu_entry_win = menu_query4_01.get();
    print("menu_entry_win: ",menu_entry_win);
    
    #if(menu_entry_win != "Click to choose option"):
    #    query5_options = list(range(window_size_max - int(menu_entry_win)));
    
    popupMenu = OptionMenu(mainframe, menu_query5_01, *query5_options);
    popupMenu.config(width = 22);
    popupMenu.grid(row = 28, column = 1);
    for space_count in range(29, 30):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
    
    def upload_q4():
        global mod1_file_path_name;
        mod1_file_path_name = "";
        print("File browser function");
        file_path_name = filedialog.askdirectory();
        #print (file_path_name);
        # Gowtham_note: Replace '/' in file path with '\\' for python versions compatibility
        mod_file_path_name = file_path_name.replace("/", "  ");
        #print ("\n mod_file_path_name = ", mod_file_path_name);
        mod1_file_path_name = mod_file_path_name.replace("  ", "\\");
        print ("\n mod1_file_path_name: ", mod1_file_path_name);
       
        #f = open("pathfile.txt", "w");
        #f.write(mod1_file_path_name);
        #f.close();
               
    # File_upload
    Label(mainframe, text = "Choose folder containing the dataset", fg = "white", bg = "black").grid(row = 31, column = 1);
    q1_button = Button(mainframe, text = "Browse", font = ("Arial", 10), width = 20, command = upload_q4);
    #mod1_file_path_name = upload_q4();
    q1_button.grid(row = 32, column = 1);
    
    # File_upload
    for space_count in range(33,34):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
            
    def page01_submit_press():
        print("Submit button press function");
        
        #f1 = open("pathfile.txt", "r");
        #file_path = f1.read();
        #print("file_path: ", file_path);
        #f1.close();
        
        #f2 = open("subject_factor.txt", "r");
        #sub_factor_value = f2.readlines();
        #print("sub_factor_value: ", sub_factor_value);
        #f2.close();
        
        if(menu_query1_01.get() == 'Click to choose option'):
            Label(mainframe, text = "Please choose valid data for the above field !", fg = "red", bg = "black").grid(row = 13, column = 1);
        elif(menu_query2_01.get() == 'Click to choose option'):
            Label(mainframe, text = "Please choose valid data for the above field !", fg = "red", bg = "black").grid(row = 18, column = 1);
        #elif(menu_query3_01_sub.get() == "Click to choose option"):
        elif not (('menu_query3_01_sub' in locals()) or ('menu_query3_01_sub' in globals())):
            Label(mainframe, text = "Please choose valid data for the above field !", fg = "red", bg = "black").grid(row = 21, column = 1);
        elif(menu_query4_01.get() == 'Click to choose option'):
            Label(mainframe, text = "Please choose valid data for the above field !", fg = "red", bg = "black").grid(row = 25, column = 1);
        #elif(menu_query5_01_win.get() == 'Click to choose option'):
        elif not (('menu_query5_01_win' in locals()) or ('menu_query5_01_win' in globals())):
            Label(mainframe, text = "Please choose valid data for the above field !", fg = "red", bg = "black").grid(row = 29, column = 1);        
        #elif(mod1_file_path_name == ""):
        elif not (('mod1_file_path_name' in locals()) or ('mod1_file_path_name' in globals())):
            Label(mainframe, text = "Please choose valid folder with input data !", fg = "red", bg = "black").grid(row = 33, column = 1);
        else:
            # Create file holding input values
            
            file_path_front = dir_os.getcwd();
            file_name_front = file_path_front + "\\" + "input_config" + ".txt";
            print("file_name_front: ", file_name_front);
            
            '''
            workbook = xlsxwriter.Workbook(file_name_front);
            worksheet = workbook.add_worksheet();
            worksheet.write(1, 0, menu_query1_01.get());
            worksheet.write(2, 0, menu_query2_01.get());
            worksheet.write(3, 0, menu_query3_01_sub.get());
            worksheet.write(4, 0, menu_query4_01.get());
            worksheet.write(5, 0, menu_query5_01_win.get());
            #worksheet.write(5, 0, file_path);
            worksheet.write(6, 0, mod1_file_path_name);
            workbook.close();
            '''
            
            file1 = open(file_name_front, "w");
            file1.write(menu_query1_01.get());
            file1.write("\n");
            file1.write(menu_query2_01.get());
            file1.write("\n");
            file1.write(menu_query3_01_sub.get());
            file1.write("\n");
            file1.write(menu_query4_01.get());
            file1.write("\n");
            file1.write(menu_query5_01_win.get());
            file1.write("\n");
            file1.write(mod1_file_path_name);
            #file1.write("\n");
            file1.close();

            print("checking file path file_path: ", mod1_file_path_name);
            print("page01_submit_press");
            root_01.destroy();
            page_02();    
        
    #submit_01 = Button(mainframe, text = "Submit", font = ("Arial", 10), width = 10, command = lambda: page01_submit_press(mod_file_path_name));
    #print ("\n mod1_file_path_name in main function: ", mod1_file_path_name);
    submit_01 = Button(mainframe, text = "Submit", font = ("Arial", 10), width = 10, command = page01_submit_press);
    submit_01.grid(row = 35, column = 1);
    for space_count in range(36,37):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
                                    
    root_01.mainloop();

def page_02():
    #global num_records;
    img_raw = Image.open(dir_os.path.join(dir_os.getcwd(), "Capture.PNG"))
    img_resize = img_raw.resize((400, 200), Image.ANTIALIAS)
    main_title = "Engineering for Health: Human Stress Analysis"
    num_subjects_max = 20;
    window_size_max = 300;
    mod1_file_path_name = "0";
        
    root_02 = Tk();
    root_02.title(main_title);
    mainframe = Frame(root_02, background = "black");
            
    mainframe.grid(column = 0,row = 0, sticky = (W,E));
    mainframe.columnconfigure(0, weight = 1);
    mainframe.rowconfigure(0, weight = 1);
    mainframe.pack();
        
    img = ImageTk.PhotoImage(img_resize);

    Label(mainframe, image = img).grid(row = 1, column = 1);
    for space_count in range(2,3):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
        
    Label(mainframe, text = main_title, fg = "white", bg = "black").grid(row = 4, column = 1);
    #Label(mainframe, text = "(Please select relevant options)").grid(row = 4, column = 1);
    for space_count in range(6,7):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
            
    page_heading = "Feature Extraction is in Progress...";
    Label(mainframe, text = page_heading, fg = "white", bg = "black").grid(row = 8, column = 1);
    for space_count in range(9,37):
        Label(mainframe, text = "", fg = "white", bg = "black").grid(row = space_count, column = 1);
            
    root_02.mainloop();

page_01();