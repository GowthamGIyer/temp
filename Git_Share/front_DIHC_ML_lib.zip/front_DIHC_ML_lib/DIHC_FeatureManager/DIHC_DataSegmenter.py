"""
File Name: HumachLab_FeatureDetails.py
Author: WWM Emran (Emran Ali)
Involvement: HumachLab & Deakin- Innovation in Healthcare (DIHC)
Email: wwm.emran@gmail.com, emran.ali@research.deakin.edu.au
Date: 3/09/2021 7:38 pm
"""

import pandas as pd

### SRART: My modules ###
#from DIHC_Package.DIHC_FeatureManager import *
#from DIHC_Package.DIHC_FeatureManager.DIHC_FeatureExtractor import *

from front_DIHC_ML_lib.DIHC_FeatureManager.DIHC_FeatureManager import *
from front_DIHC_ML_lib.DIHC_FeatureManager.DIHC_FeatureExtractor import *
### END: My modules ###


class DIHC_DataSegmenter:

    # ## Initialization
    def __init__(self, data, segment_length=None, segment_overlap=0, signal_frequency=1):
        self.data = data
        self.segment_length = segment_length
        self.segment_overlap = segment_overlap
        self.signal_frequency = signal_frequency
        return

    # ## Data Segmentor
    def generate_segments(self):
        if len(self.data)==0:
            print(f'Data is empty...')
            exit(0)
            # return

        # Gowtham_edit
        #self.segment_length = 1;
        
        if self.segment_length is None:
            print(f'Dealing with entire signal...')
        else:
            if (self.segment_length*self.signal_frequency) > len(self.data):
                print(f'Data can\'t be segmented...')
                return self.data
            else:
                seg_srl = 1
                seg_st = 0
                seg_len = self.segment_length*self.signal_frequency
                
                print("self.segment_length", self.segment_length);
                print("self.signal_frequency", self.signal_frequency);
                seg_mov = seg_len-(self.segment_overlap*self.signal_frequency)
                print(f'Segment started...')
                print("seg_st", seg_st);
                print("data_len", len(self.data));
                print("seg_len", seg_len);
                print("seg_mov", seg_mov);
                seg_len = len(self.data);
                seg_mov = len(self.data);
                
                while (seg_st<len(self.data)):
                    print(f'Generating segment# {seg_srl}')
                    seg_end = seg_st+seg_len
                    seg_data = self.data[seg_st:seg_end]
                    yield seg_data
                    seg_st += seg_mov
                    seg_srl += 1
                print(f'Segment finished...')
        return


