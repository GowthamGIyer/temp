"""
File Name: __init__.py.py 
Author: WWM Emran (Emran Ali)
Email: wwm.emran@gmail.com, emran.ali@research.deakin.edu.au 
Date: 10/05/2022 9:49 pm
"""


#from DIHC_Package.DIHC_FeatureManager import *
#from DIHC_Package.DIHC_FeatureManager.DIHC_FeatureExtractor import *
#from DIHC_Package.DIHC_FeatureManager.DIHC_FeatureDetails import *

from front_DIHC_ML_lib.DIHC_FeatureManager.DIHC_FeatureManager import *
from front_DIHC_ML_lib.DIHC_FeatureManager.DIHC_FeatureExtractor import *
from front_DIHC_ML_lib.DIHC_FeatureManager.DIHC_FeatureDetails import *

# import DIHC_FeatureManager
# import DIHC_FeatureExtractor
# import DIHC_FeatureDetails

